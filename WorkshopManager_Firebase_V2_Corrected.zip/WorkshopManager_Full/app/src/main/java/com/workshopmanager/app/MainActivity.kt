package com.workshopmanager.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }
    private var currentName = ""
    private var currentRole = "Technician"
    private var selectedBefore: Uri? = null
    private var selectedAfter: Uri? = null
    private var pendingPhotoType = "before"
    private var cameraUri: Uri? = null
    private var photoStatusView: TextView? = null
    private var beforeImage: ImageView? = null
    private var afterImage: ImageView? = null

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) {
            if (pendingPhotoType == "before") selectedBefore = cameraUri else selectedAfter = cameraUri
            updatePhotoPreview()
            toast("${pendingPhotoType.replaceFirstChar { it.uppercase() }} photo captured")
        } else if (!ok) toast("Photo capture cancelled")
    }
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (pendingPhotoType == "before") selectedBefore = uri else selectedAfter = uri
            updatePhotoPreview()
            toast("${pendingPhotoType.replaceFirstChar { it.uppercase() }} photo selected")
        }
    }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else toast("Camera permission is required")
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }

    private fun base() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
    private fun title(t: String) = TextView(this).apply { text=t; textSize=25f; setPadding(0,0,0,18); gravity=Gravity.CENTER }
    private fun btn(t: String, action: () -> Unit) = Button(this).apply { text=t; setOnClickListener { action() } }
    private fun input(h: String) = EditText(this).apply { hint=h; setPadding(18,12,18,12) }
    private fun scroll(content: View) = ScrollView(this).apply { addView(content) }
    private fun toast(s: String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()

    private fun showLogin() {
        val l=base(); l.addView(title("Workshop Manager"))
        val email=input("Email"); val pass=input("Password"); pass.inputType=129
        l.addView(email); l.addView(pass)
        l.addView(btn("LOGIN") {
            if (email.text.toString().trim().isEmpty() || pass.text.toString().isEmpty()) { toast("Enter email and password"); return@btn }
            auth.signInWithEmailAndPassword(email.text.toString().trim(),pass.text.toString())
                .addOnSuccessListener { loadUser() }
                .addOnFailureListener { toast(it.message ?: "Login failed") }
        })
        l.addView(TextView(this).apply { text="Workshop Department • Cloud version"; textSize=14f; gravity=Gravity.CENTER; setPadding(0,25,0,0) })
        setContentView(l)
    }

    private fun loadUser() {
        val uid=auth.currentUser?.uid ?: return
        db.collection("users").document(uid).get()
            .addOnSuccessListener { d ->
                currentName=d.getString("name") ?: "User"
                currentRole=d.getString("role") ?: "Technician"
                registerToken(); showDashboard()
            }
            .addOnFailureListener { toast("Could not load profile: ${it.message}"); auth.signOut(); showLogin() }
    }

    private fun registerToken() {
        val uid=auth.currentUser?.uid ?: return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
            db.collection("deviceTokens").document(uid).set(mapOf("token" to t,"name" to currentName,"updatedAt" to System.currentTimeMillis()))
        }
    }

    private fun showDashboard() {
        val l=base(); l.addView(title("Workshop Dashboard"))
        l.addView(TextView(this).apply{text="$currentName  •  $currentRole";textSize=17f;gravity=Gravity.CENTER;setPadding(0,0,0,15)})
        val summary=TextView(this).apply{text="Loading work summary...";textSize=16f;setPadding(0,10,0,20)}; l.addView(summary)
        l.addView(btn("WORK ORDERS") { showOrders() })
        if(currentRole=="Boss") l.addView(btn("NEW WORK REQUEST") { showNewOrder() })
        l.addView(btn("MATERIAL REQUESTS") { showMaterials() })
        l.addView(btn("REPORTS") { showReports() })
        l.addView(btn("PROFILE / LOG OUT") { auth.signOut(); selectedBefore=null; selectedAfter=null; showLogin() })
        setContentView(scroll(l))
        db.collection("workOrders").get()
            .addOnSuccessListener { docs ->
                val visible=visibleOrders(docs.documents)
                val n=visible.size; val inProg=visible.count{it.getString("status")=="In Progress"}; val wait=visible.count{it.getString("status")=="Waiting for Material"}; val done=visible.count{it.getString("status")=="Completed"||it.getString("status")=="Closed"}
                summary.text="Total: $n\nIn progress: $inProg\nWaiting material: $wait\nCompleted/closed: $done"
            }
            .addOnFailureListener { summary.text="Unable to load work summary\n${it.message ?: "Check Firestore rules/internet"}" }
    }

    private fun visibleOrders(docs: List<com.google.firebase.firestore.DocumentSnapshot>): List<com.google.firebase.firestore.DocumentSnapshot> {
        if(currentRole=="Boss" || currentRole=="Team Leader") return docs
        return docs.filter { (it.getString("assignedNames") ?: "").split(", ").contains(currentName) }
    }

    private fun showOrders() {
        val l=base(); l.addView(title("Work Orders")); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; l.addView(list)
        db.collection("workOrders").orderBy("createdAt",Query.Direction.DESCENDING).get()
            .addOnSuccessListener { snap ->
                list.removeAllViews(); val docs=visibleOrders(snap.documents)
                if(docs.isEmpty()) list.addView(TextView(this).apply{text="No work orders assigned yet.";textSize=18f;setPadding(0,20,0,20)})
                docs.forEach { d ->
                    val text="${d.id}\n${d.getString("description") ?: "No description"}\nAssigned: ${d.getString("assignedNames") ?: "Not assigned"}\nStatus: ${d.getString("status") ?: "New"}"
                    list.addView(btn(text){showOrderDetail(d.id)})
                }
            }
            .addOnFailureListener { list.addView(TextView(this).apply{text="Could not load work orders.\n${it.message}"}); }
        if(currentRole=="Boss") l.addView(btn("NEW WORK REQUEST") { showNewOrder() })
        l.addView(btn("BACK") { showDashboard() }); setContentView(scroll(l))
    }

    private fun showNewOrder() {
        if(currentRole!="Boss"){toast("Only Boss can create and assign work requests");return}
        val l=base(); l.addView(title("New Work Request"))
        val dept=input("Requesting department"); val loc=input("Location / house"); val req=input("Requester"); val desc=input("Problem / work description")
        val pri=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Normal","High","Urgent"))}
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Individual","Team"))}
        l.addView(dept);l.addView(loc);l.addView(req);l.addView(desc);l.addView(pri);l.addView(type)
        l.addView(TextView(this).apply{text="Assign by employee name";textSize=17f;setPadding(0,15,0,8)})
        val staff=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; l.addView(staff); val selected=linkedSetOf<String>()
        db.collection("users").get().addOnSuccessListener { snap ->
            staff.removeAllViews(); snap.documents.sortedBy{it.getString("name") ?: ""}.forEach { d ->
                val name=d.getString("name") ?: return@forEach
                if(name=="Mr. Luther") return@forEach
                staff.addView(CheckBox(this).apply{text=name;setOnCheckedChangeListener{_,checked->if(checked)selected.add(name) else selected.remove(name)}})
            }
            if(staff.childCount==0) staff.addView(TextView(this).apply{text="No staff profiles found"})
        }.addOnFailureListener{staff.addView(TextView(this).apply{text="Could not load staff: ${it.message}"})}
        l.addView(btn("CREATE WORK ORDER") {
            if(desc.text.toString().trim().isEmpty()){toast("Enter work description");return@btn}
            if(selected.isEmpty()){toast("Select at least one employee by name");return@btn}
            if(type.selectedItem.toString()=="Individual" && selected.size>1){toast("Individual job: select one employee, or choose Team");return@btn}
            val number="WO-"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())
            val data=hashMapOf<String,Any>("requestNumber" to number,"requestingDepartment" to dept.text.toString(),"location" to loc.text.toString(),"requester" to req.text.toString(),"description" to desc.text.toString(),"priority" to pri.selectedItem.toString(),"jobType" to type.selectedItem.toString(),"assignedNames" to selected.joinToString(", "),"assignedUids" to emptyList<String>(),"status" to "Assigned","createdBy" to currentName,"createdByUid" to (auth.currentUser?.uid ?: ""),"createdAt" to System.currentTimeMillis())
            db.collection("workOrders").document(number).set(data).addOnSuccessListener{toast("Work order $number created and assigned");showOrders()}.addOnFailureListener{toast("Create failed: ${it.message}")}
        })
        l.addView(btn("BACK"){showDashboard()}); setContentView(scroll(l))
    }

    private fun showOrderDetail(id:String) {
        db.collection("workOrders").document(id).get().addOnSuccessListener { d ->
            if(!d.exists()){toast("Work order not found");showOrders();return@addOnSuccessListener}
            val assigned=d.getString("assignedNames") ?: ""
            if(currentRole!="Boss" && currentRole!="Team Leader" && !assigned.split(", ").contains(currentName)){toast("This work order is not assigned to you");showOrders();return@addOnSuccessListener}
            val l=base(); l.addView(title(id))
            l.addView(TextView(this).apply{text="Department: ${d.getString("requestingDepartment") ?: "-"}\nLocation: ${d.getString("location") ?: "-"}\nRequester: ${d.getString("requester") ?: "-"}\nPriority: ${d.getString("priority") ?: "-"}\nJob type: ${d.getString("jobType") ?: "-"}\nAssigned: $assigned\nStatus: ${d.getString("status") ?: "Assigned"}\n\n${d.getString("description") ?: ""}";textSize=16f;setPadding(0,0,0,15)})
            val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Assigned","In Progress","Waiting for Material","Completed","Closed"));setSelection(maxOf(0,(adapter as ArrayAdapter<String>).getPosition(d.getString("status") ?: "Assigned")))}
            l.addView(TextView(this).apply{text="Update status";textSize=16f});l.addView(status)
            l.addView(btn("UPDATE STATUS"){db.collection("workOrders").document(id).update("status",status.selectedItem.toString()).addOnSuccessListener{toast("Status updated");showOrderDetail(id)}.addOnFailureListener{toast("Status update failed: ${it.message}")}})
            l.addView(btn("REQUEST MATERIAL"){showMaterialForm(id)})
            l.addView(btn("COMPLETION REPORT + BEFORE/AFTER PHOTOS"){showCompletion(id)})
            if(currentRole=="Boss") l.addView(btn("DELETE WORK ORDER"){confirmDeleteOrder(id)})
            l.addView(btn("BACK"){showOrders()}); setContentView(scroll(l))
        }.addOnFailureListener{toast("Could not open work order: ${it.message}");showOrders()}
    }

    private fun confirmDeleteOrder(id:String){AlertDialog.Builder(this).setTitle("Delete work order?").setMessage(id).setPositiveButton("DELETE"){_,_->db.collection("workOrders").document(id).delete().addOnSuccessListener{toast("Deleted");showOrders()}.addOnFailureListener{toast("Delete failed: ${it.message}")}}.setNegativeButton("CANCEL",null).show()}

    private fun showMaterialForm(orderId:String?=null){
        val l=base();l.addView(title("Material Request"));
        val material=input("Material name");val quantity=input("Quantity");val reason=input("Reason / why needed");l.addView(material);l.addView(quantity);l.addView(reason)
        val order=input("Work order number (optional)"); if(orderId!=null){order.setText(orderId);order.isEnabled=false};l.addView(order)
        l.addView(btn("SUBMIT MATERIAL REQUEST"){
            if(material.text.toString().trim().isEmpty()||quantity.text.toString().trim().isEmpty()){toast("Enter material and quantity");return@btn}
            val data=mapOf("workOrderId" to order.text.toString().trim(),"material" to material.text.toString().trim(),"quantity" to quantity.text.toString().trim(),"reason" to reason.text.toString().trim(),"requestedBy" to currentName,"requestedByUid" to (auth.currentUser?.uid ?: ""),"status" to "Requested","createdAt" to System.currentTimeMillis())
            db.collection("materialRequests").add(data).addOnSuccessListener{toast("Material request submitted");showMaterials()}.addOnFailureListener{toast("Material request failed: ${it.message}")}
        });l.addView(btn("BACK"){if(orderId!=null)showOrderDetail(orderId) else showDashboard()});setContentView(scroll(l))
    }

    private fun showMaterials(){
        val l=base();l.addView(title("Material Requests"));l.addView(btn("+ NEW MATERIAL REQUEST"){showMaterialForm(null)})
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};l.addView(list)
        db.collection("materialRequests").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener{snap->
            list.removeAllViews();
            if(snap.isEmpty) list.addView(TextView(this).apply{text="No material requests yet.";textSize=18f;setPadding(0,20,0,20)})
            snap.documents.forEach{d->
                val text="${d.getString("material") ?: "-"} • ${d.getString("quantity") ?: "-"}\nStatus: ${d.getString("status") ?: "Requested"}\nRequested by: ${d.getString("requestedBy") ?: "-"}\nWork order: ${d.getString("workOrderId") ?: "-"}"
                if(currentRole=="Boss"||currentRole=="Team Leader") list.addView(btn(text){showMaterialStatus(d.id,d.getString("status") ?: "Requested")}) else if(d.getString("requestedByUid")==auth.currentUser?.uid) list.addView(btn(text){showMaterialStatusReadOnly(text)})
            }
        }.addOnFailureListener{list.addView(TextView(this).apply{text="Could not load material requests.\n${it.message}"})}
        l.addView(btn("BACK"){showDashboard()});setContentView(scroll(l))
    }

    private fun showMaterialStatusReadOnly(text:String){AlertDialog.Builder(this).setTitle("Material Request").setMessage(text).setPositiveButton("OK",null).show()}
    private fun showMaterialStatus(id:String,current:String){
        val opts=arrayOf("Requested","Approved","Purchased","Rejected")
        val s=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,opts);setSelection(opts.indexOf(current).coerceAtLeast(0))}
        AlertDialog.Builder(this).setTitle("Update material status").setView(s).setPositiveButton("SAVE"){_,_->db.collection("materialRequests").document(id).update("status",s.selectedItem.toString()).addOnSuccessListener{toast("Material status updated");showMaterials()}.addOnFailureListener{toast("Update failed: ${it.message}")}}.setNegativeButton("CANCEL",null).show()
    }

    private fun showCompletion(id:String){
        selectedBefore=null;selectedAfter=null
        val l=base();l.addView(title("Completion Report"));
        val problem=input("What was the problem?");val work=input("What was done?");val used=input("Material used");val extra=input("Additional problem / note");l.addView(problem);l.addView(work);l.addView(used);l.addView(extra)
        l.addView(TextView(this).apply{text="BEFORE PHOTO";textSize=18f;setPadding(0,16,0,6)})
        beforeImage=ImageView(this).apply{adjustViewBounds=true;minimumHeight=120};l.addView(beforeImage)
        l.addView(btn("📷 CAPTURE BEFORE PHOTO"){capture("before")});l.addView(btn("🖼 SELECT BEFORE PHOTO"){selectGallery("before")})
        l.addView(TextView(this).apply{text="AFTER PHOTO";textSize=18f;setPadding(0,16,0,6)})
        afterImage=ImageView(this).apply{adjustViewBounds=true;minimumHeight=120};l.addView(afterImage)
        l.addView(btn("📷 CAPTURE AFTER PHOTO"){capture("after")});l.addView(btn("🖼 SELECT AFTER PHOTO"){selectGallery("after")})
        photoStatusView=TextView(this).apply{text="No photos selected";textSize=15f;setPadding(0,10,0,10)};l.addView(photoStatusView)
        l.addView(btn("SAVE COMPLETION"){if(work.text.toString().trim().isEmpty()){toast("Enter what was done");return@btn};val data=hashMapOf<String,Any>("completionProblem" to problem.text.toString(),"completionWork" to work.text.toString(),"materialUsed" to used.text.toString(),"additionalNote" to extra.text.toString(),"completedBy" to currentName,"completedByUid" to (auth.currentUser?.uid ?: ""),"completedAt" to System.currentTimeMillis(),"status" to "Completed");uploadIfNeeded(id,data)})
        l.addView(btn("BACK"){showOrderDetail(id)});setContentView(scroll(l))
    }

    private fun uploadIfNeeded(id:String,data:HashMap<String,Any>){
        val uris=listOf("before" to selectedBefore,"after" to selectedAfter).filter{it.second!=null}
        if(uris.isEmpty()){saveCompletion(id,data);return}
        var remaining=uris.size
        uris.forEach{pair->
            val type=pair.first;val uri=pair.second!!;val ref=storage.reference.child("workOrders/$id/$type-${System.currentTimeMillis()}.jpg")
            ref.putFile(uri).continueWithTask{if(!it.isSuccessful)throw(it.exception ?: Exception("Upload failed"));ref.downloadUrl}
                .addOnSuccessListener{url->data["${type}PhotoUrl"]=url.toString();remaining--;if(remaining==0)saveCompletion(id,data)}
                .addOnFailureListener{toast("Photo upload failed: ${it.message}\nFirebase Storage must be enabled before server photo storage can work.")}
        }
    }
    private fun saveCompletion(id:String,data:HashMap<String,Any>){db.collection("workOrders").document(id).update(data).addOnSuccessListener{toast("Completion report saved");showOrderDetail(id)}.addOnFailureListener{toast("Could not save completion: ${it.message}")}}

    private fun capture(type:String){pendingPhotoType=type;if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)launchCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)}
    private fun selectGallery(type:String){pendingPhotoType=type;galleryLauncher.launch("image/*")}
    private fun launchCamera(){val dir=File(cacheDir,"images").apply{mkdirs()};val f=File(dir,"${pendingPhotoType}_${System.currentTimeMillis()}.jpg");cameraUri=FileProvider.getUriForFile(this,"com.workshopmanager.app.fileprovider",f);cameraUri?.let{cameraLauncher.launch(it)}}
    private fun updatePhotoPreview(){beforeImage?.setImageURI(selectedBefore);afterImage?.setImageURI(selectedAfter);photoStatusView?.text="Before: ${if(selectedBefore!=null)"Selected" else "Not selected"}\nAfter: ${if(selectedAfter!=null)"Selected" else "Not selected"}"}

    private fun showReports(){
        val l=base();l.addView(title("Reports"));val t=TextView(this).apply{text="Loading reports...";textSize=16f};l.addView(t)
        db.collection("workOrders").get().addOnSuccessListener{docs->val visible=visibleOrders(docs.documents);val byStatus=visible.groupingBy{it.getString("status") ?: "Unknown"}.eachCount();t.text="Total work orders: ${visible.size}\n\n"+if(byStatus.isEmpty())"No work orders yet." else byStatus.entries.sortedBy{it.key}.joinToString("\n"){ "${it.key}: ${it.value}" }}.addOnFailureListener{t.text="Could not load reports.\n${it.message}"}
        l.addView(btn("BACK"){showDashboard()});setContentView(scroll(l))
    }
}
