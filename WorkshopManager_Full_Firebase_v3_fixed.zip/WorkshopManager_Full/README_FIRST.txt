WORKSHOP MANAGER - FULL FIREBASE ANDROID SOURCE

Firebase project: workshope-68a8e
Android package: com.workshopmanager.app

Included:
- Email/password login
- Firestore shared work orders
- Boss-only work request creation
- Individual/team assignment by employee name
- Status tracking
- Material requests
- Before/after photo capture and Firebase Storage upload code
- FCM token registration and notification receiver
- Dashboard and reports
- Firestore security rules
- GitHub Actions workflow that builds a debug APK without a Gradle wrapper

IMPORTANT:
1. Firebase Storage is included in the code, but actual photo upload requires Firebase Storage to be enabled/billing configured in the Firebase project.
2. The supplied google-services.json is already included for package com.workshopmanager.app.
3. The current Firestore rules should be published in Firebase Console before production use.
4. The GitHub Actions workflow builds a DEBUG APK. A signed release APK/AAB needs a release keystore and signing configuration.
