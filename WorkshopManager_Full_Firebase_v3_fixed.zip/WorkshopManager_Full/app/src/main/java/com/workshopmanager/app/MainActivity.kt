package com.workshopmanager.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }
    private var currentName = ""
    private var currentRole = ""
    private var selectedBefore: Uri? = null
    private var selectedAfter: Uri? = null
    private var pendingPhotoType = "before"
    private var cameraUri: Uri? = null

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) { if (pendingPhotoType == "before") selectedBefore = cameraUri else selectedAfter = cameraUri; toast("${pendingPhotoType.capitalize()} photo captured") }
    }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else toast("Camera permission is required for photo capture")
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }
    private fun base(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
    private fun title(t:String)=TextView(this).apply { text=t; textSize=25f; setPadding(0,0,0,18); gravity=Gravity.CENTER }
    private fun btn(t:String, action:()->Unit)=Button(this).apply { text=t; setOnClickListener{action()} }
    private fun input(h:String)=EditText(this).apply { hint=h; setPadding(18,12,18,12) }
    private fun scroll(content: View)=ScrollView(this).apply{ addView(content) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    private fun showLogin(){
        val l=base(); l.addView(title("Workshop Manager"));
        val email=input("Email"); val pass=input("Password"); pass.inputType=129
        l.addView(email); l.addView(pass); l.addView(btn("LOGIN"){ auth.signInWithEmailAndPassword(email.text.toString().trim(),pass.text.toString()).addOnSuccessListener{loadUser()}.addOnFailureListener{toast(it.message?:"Login failed")} })
        l.addView(TextView(this).apply{ text="Workshop Department • Cloud version"; textSize=14f; gravity=Gravity.CENTER; setPadding(0,25,0,0) })
        setContentView(l)
    }
    private fun loadUser(){ db.collection("users").document(auth.currentUser!!.uid).get().addOnSuccessListener{ d -> currentName=d.getString("name")?:"User"; currentRole=d.getString("role")?:"Technician"; registerToken(); showDashboard() }.addOnFailureListener{toast("Could not load user profile")} }
    private fun registerToken(){ FirebaseMessaging.getInstance().token.addOnSuccessListener{t-> db.collection("deviceTokens").document(auth.currentUser!!.uid).set(mapOf("token" to t,"name" to currentName,"updatedAt" to System.currentTimeMillis())) } }

    private fun showDashboard(){
        val l=base(); l.addView(title("Workshop Dashboard")); l.addView(TextView(this).apply{text="$currentName  •  $currentRole";textSize=17f;gravity=Gravity.CENTER})
        val summary=TextView(this).apply{text="Loading...";textSize=16f;setPadding(0,20,0,20)}; l.addView(summary)
        l.addView(btn("WORK ORDERS"){showOrders()}); if(currentRole=="Boss") l.addView(btn("NEW WORK REQUEST"){showNewOrder()}); l.addView(btn("MATERIAL REQUESTS"){showMaterials()}); l.addView(btn("REPORTS"){showReports()}); l.addView(btn("PROFILE / LOG OUT"){auth.signOut();showLogin()}); setContentView(scroll(l))
        db.collection("workOrders").get().addOnSuccessListener{docs-> val n=docs.count(); val inProg=docs.count{it.getString("status")=="In Progress"}; val wait=docs.count{it.getString("status")=="Waiting for Material"}; val done=docs.count{it.getString("status")=="Completed"||it.getString("status")=="Closed"}; summary.text="Total: $n\nIn progress: $inProg\nWaiting material: $wait\nCompleted/closed: $done" }
    }

    private fun showOrders(){
        val l=base(); l.addView(title("Work Orders")); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; l.addView(list)
        db.collection("workOrders").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener{snap-> list.removeAllViews(); if(snap.isEmpty) list.addView(TextView(this).apply{text="No work orders yet."}); for(d in snap){ val text="${d.id}\n${d.getString("description")?:""}\nAssigned: ${d.getString("assignedNames")?:""}\nStatus: ${d.getString("status")?:"New"}"; list.addView(btn(text){showOrderDetail(d.id)}) }}.addOnFailureListener{toast("Could not load work orders")}
        l.addView(btn("BACK"){showDashboard()}); setContentView(scroll(l))
    }

    private fun showNewOrder(){
        val l=base(); l.addView(title("New Work Request")); val dept=input("Requesting department"); val loc=input("Location / house"); val req=input("Requester"); val desc=input("Problem / work description"); val pri=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Normal","High","Urgent"))}; val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Individual","Team"))};
        l.addView(dept);l.addView(loc);l.addView(req);l.addView(desc);l.addView(pri);l.addView(type); l.addView(TextView(this).apply{text="Assign by employee name (select one or more).";setPadding(0,15,0,8)})
        val staff=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; l.addView(staff); val selected=mutableSetOf<String>()
        db.collection("users").get().addOnSuccessListener{snap-> for(d in snap){ val name=d.getString("name")?:continue; if(name=="Mr. Luther") continue; val cb=CheckBox(this).apply{text=name;setOnCheckedChangeListener{_,c->if(c)selected.add(name) else selected.remove(name)}}; staff.addView(cb) } }
        l.addView(btn("CREATE WORK ORDER"){ if(desc.text.toString().trim().isEmpty()||selected.isEmpty()){toast("Enter description and select employee(s)");return@btn}; val number="WO-"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date()); val data=hashMapOf("requestNumber" to number,"requestingDepartment" to dept.text.toString(),"location" to loc.text.toString(),"requester" to req.text.toString(),"description" to desc.text.toString(),"priority" to pri.selectedItem.toString(),"jobType" to type.selectedItem.toString(),"assignedNames" to selected.joinToString(", "),"assignedUids" to emptyList<String>(),"status" to "Assigned","createdBy" to currentName,"createdByUid" to auth.currentUser!!.uid,"createdAt" to System.currentTimeMillis()); db.collection("workOrders").document(number).set(data).addOnSuccessListener{toast("Created $number");showOrders()}.addOnFailureListener{toast(it.message?:"Create failed")} }); l.addView(btn("BACK"){showDashboard()}); setContentView(scroll(l))
    }

    private fun showOrderDetail(id:String){
        db.collection("workOrders").document(id).get().addOnSuccessListener{d->
            if(!d.exists()){toast("Not found");return@addOnSuccessListener}; val l=base();l.addView(title(id)); val info=TextView(this).apply{text="Department: ${d.getString("requestingDepartment")}\nLocation: ${d.getString("location")}\nPriority: ${d.getString("priority")}\nAssigned: ${d.getString("assignedNames")}\nStatus: ${d.getString("status")}\n\n${d.getString("description")}";textSize=16f};l.addView(info)
            val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Assigned","In Progress","Waiting for Material","Completed","Closed")); setSelection(maxOf(0, (adapter as ArrayAdapter<String>).getPosition(d.getString("status")?:"Assigned")))}; l.addView(status); l.addView(btn("UPDATE STATUS"){db.collection("workOrders").document(id).update("status",status.selectedItem.toString()).addOnSuccessListener{toast("Status updated");showOrderDetail(id)}})
            l.addView(btn("REQUEST MATERIAL"){showMaterialForm(id)}); l.addView(btn("COMPLETION REPORT + PHOTOS"){showCompletion(id)}); l.addView(btn("BACK"){showOrders()});setContentView(scroll(l))
        }
    }

    private fun showMaterialForm(orderId:String){ val l=base();l.addView(title("Material Request"));val m=input("Material name");val q=input("Quantity");val r=input("Reason");l.addView(m);l.addView(q);l.addView(r);l.addView(btn("SUBMIT"){val data=mapOf("workOrderId" to orderId,"material" to m.text.toString(),"quantity" to q.text.toString(),"reason" to r.text.toString(),"requestedBy" to currentName,"requestedByUid" to auth.currentUser!!.uid,"status" to "Requested","createdAt" to System.currentTimeMillis());db.collection("materialRequests").add(data).addOnSuccessListener{toast("Material request submitted");showOrderDetail(orderId)}});l.addView(btn("BACK"){showOrderDetail(orderId)});setContentView(scroll(l)) }

    private fun showMaterials(){ val l=base();l.addView(title("Material Requests"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};l.addView(list);db.collection("materialRequests").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener{for(d in it){val id=d.id;list.addView(btn("${d.getString("material")} • ${d.getString("quantity")}\n${d.getString("status")} • ${d.getString("requestedBy")}"){ if(currentRole=="Boss"||currentRole=="Team Leader") showMaterialStatus(id,d.getString("status")?:"Requested")})}};l.addView(btn("BACK"){showDashboard()});setContentView(scroll(l)) }
    private fun showMaterialStatus(id:String,current:String){val opts=arrayOf("Requested","Approved","Purchased","Rejected");val s=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,opts);setSelection(opts.indexOf(current).coerceAtLeast(0))};AlertDialogCompat(this).show("Material status",s){db.collection("materialRequests").document(id).update("status",s.selectedItem.toString()).addOnSuccessListener{toast("Updated")}.also{showMaterials()}}}

    private fun showCompletion(id:String){ val l=base();l.addView(title("Completion Report"));val problem=input("What was the problem?");val work=input("What was done?");val used=input("Material used");val extra=input("Additional problem / note");l.addView(problem);l.addView(work);l.addView(used);l.addView(extra);val b=btn("CAPTURE BEFORE PHOTO"){capture("before")};val a=btn("CAPTURE AFTER PHOTO"){capture("after")};l.addView(b);l.addView(a);val status=TextView(this).apply{text="No photos selected"};l.addView(status);l.addView(btn("SAVE COMPLETION"){val baseData=hashMapOf<String,Any>("completionProblem" to problem.text.toString(),"completionWork" to work.text.toString(),"materialUsed" to used.text.toString(),"additionalNote" to extra.text.toString(),"completedBy" to currentName,"completedAt" to System.currentTimeMillis(),"status" to "Completed"); uploadIfNeeded(id,baseData,status)});l.addView(btn("BACK"){showOrderDetail(id)});setContentView(scroll(l)) }

    private fun uploadIfNeeded(id:String,data:HashMap<String,Any>,status:TextView){ val uris=listOf("before" to selectedBefore,"after" to selectedAfter); fun save(){db.collection("workOrders").document(id).update(data).addOnSuccessListener{toast("Completion saved");showOrderDetail(id)}}; if(uris.all{it.second==null}){save();return}; var remaining=uris.count{it.second!=null}; for((type,uri) in uris){if(uri==null)continue; val ref=storage.reference.child("workOrders/$id/$type-${System.currentTimeMillis()}.jpg");ref.putFile(uri).continueWithTask{ref.downloadUrl}.addOnSuccessListener{url->data["${type}PhotoUrl"]=url.toString();remaining--;if(remaining==0)save()}.addOnFailureListener{toast("Photo upload failed. Enable Firebase Storage/billing, then try again.")}} }

    private fun capture(type:String){pendingPhotoType=type; if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)launchCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)}
    private fun launchCamera(){val dir=File(cacheDir,"images").apply{mkdirs()};val f=File(dir,"${pendingPhotoType}_${System.currentTimeMillis()}.jpg");cameraUri=FileProvider.getUriForFile(this,"com.workshopmanager.app.fileprovider",f);cameraLauncher.launch(cameraUri)}

    private fun showReports(){val l=base();l.addView(title("Reports"));val t=TextView(this).apply{text="Loading...";textSize=16f};l.addView(t);db.collection("workOrders").get().addOnSuccessListener{docs->val byStatus=docs.groupingBy{it.getString("status")?:"Unknown"}.eachCount();t.text="Total work orders: ${docs.size()}\n"+byStatus.entries.joinToString("\n"){"${it.key}: ${it.value}"}};l.addView(btn("BACK"){showDashboard()});setContentView(scroll(l))}
}

private class AlertDialogCompat(private val a:Activity){fun show(title:String,view:View,onOk:()->Unit){android.app.AlertDialog.Builder(a).setTitle(title).setView(view).setPositiveButton("SAVE"){_,_->onOk()}.setNegativeButton("CANCEL",null).show()}}
