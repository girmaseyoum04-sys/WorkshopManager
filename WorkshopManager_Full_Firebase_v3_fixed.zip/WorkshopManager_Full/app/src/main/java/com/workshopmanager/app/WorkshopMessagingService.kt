package com.workshopmanager.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class WorkshopMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val manager=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channelId="workshop"
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channelId,"Workshop notifications",NotificationManager.IMPORTANCE_DEFAULT))
        val intent=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n=NotificationCompat.Builder(this,channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(message.notification?.title ?: "Workshop Manager").setContentText(message.notification?.body ?: "New workshop update").setAutoCancel(true).setContentIntent(intent).build()
        manager.notify((System.currentTimeMillis()%100000).toInt(),n)
    }
}
