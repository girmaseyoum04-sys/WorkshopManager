const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();

async function sendToUsers(uids, title, body, data = {}) {
  const unique = [...new Set((uids || []).filter(Boolean))];
  if (!unique.length) return;
  const docs = await Promise.all(unique.map(uid => db.collection('deviceTokens').doc(uid).get()));
  const tokens = docs.map(d => d.exists ? d.get('token') : null).filter(Boolean);
  if (!tokens.length) return;
  await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v ?? '')]))
  });
}

exports.notifyNewWorkOrder = onDocumentCreated('workOrders/{id}', async event => {
  const data = event.data.data();
  await sendToUsers(data.assignedUids || [], 'New work assigned', `${data.requestNumber || event.params.id} has been assigned to you.`, { workOrderId: event.params.id });
});

exports.notifyWorkOrderStatus = onDocumentUpdated('workOrders/{id}', async event => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if ((before.status || '') === (after.status || '')) return;
  await sendToUsers(after.assignedUids || [], 'Work order status changed', `${after.requestNumber || event.params.id}: ${after.status || ''}`, { workOrderId: event.params.id });
});

exports.notifyMaterialRequest = onDocumentCreated('materialRequests/{id}', async event => {
  const data = event.data.data();
  const users = await db.collection('users').get();
  const recipients = users.docs.filter(d => ['Boss', 'Team Leader'].includes(d.get('role'))).map(d => d.id);
  await sendToUsers(recipients, 'New material request', `${data.material || 'Material'} • ${data.quantity || ''}`, { materialRequestId: event.params.id });
});

exports.notifyMaterialStatus = onDocumentUpdated('materialRequests/{id}', async event => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if ((before.status || '') === (after.status || '')) return;
  await sendToUsers([after.requestedByUid], 'Material request updated', `${after.material || 'Material'}: ${after.status || ''}`, { materialRequestId: event.params.id });
});
