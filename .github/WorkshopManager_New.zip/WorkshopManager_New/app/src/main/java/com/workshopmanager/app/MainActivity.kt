package com.workshopmanager.app

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import android.util.Base64

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val executor = Executors.newSingleThreadExecutor()

    private var currentName: String? = null
    private var currentRole: String? = null
    private var notificationListener: ListenerRegistration? = null
    private var notificationListenerReady = false

    private var selectedBefore: Uri? = null
    private var selectedAfter: Uri? = null
    private var pendingPhotoType = "before"
    private var cameraUri: Uri? = null
    private var beforeImage: ImageView? = null
    private var afterImage: ImageView? = null
    private var photoStatus: TextView? = null

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && cameraUri != null) {
            if (pendingPhotoType == "before") selectedBefore = cameraUri else selectedAfter = cameraUri
            updatePhotoPreview()
            toast("${pendingPhotoType.uppercase(Locale.US)} photo captured")
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (pendingPhotoType == "before") selectedBefore = uri else selectedAfter = uri
            updatePhotoPreview()
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else toast("Camera permission is required to take a photo")
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    override fun onDestroy() {
        notificationListener?.remove()
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(28, 28, 28, 28)
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 25f
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, 18)
    }

    private fun btn(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }

    private fun input(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        setPadding(18, 12, 18, 12)
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply { addView(content) }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun showLogin() {
        val root = base()
        root.addView(title("Workshop Manager"))
        root.addView(TextView(this).apply {
            text = "Workshop Department • Cloud version"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })
        val email = input("Email")
        val password = input("Password").apply { inputType = 129 }
        root.addView(email)
        root.addView(password)
        root.addView(btn("LOGIN") {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            if (e.isEmpty() || p.isEmpty()) {
                toast("Enter email and password")
                return@btn
            }
            auth.signInWithEmailAndPassword(e, p)
                .addOnSuccessListener { loadUserProfile() }
                .addOnFailureListener { toast("Login failed: ${it.message ?: "Unknown error"}") }
        })
        root.addView(TextView(this).apply {
            text = "Your name and role are read from Firebase users/{your UID}."
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        })
        setContentView(scroll(root))
    }

    private fun loadUserProfile() {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            toast("Authentication session is missing")
            showLogin()
            return
        }
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    showProfileError("User profile not found in Firestore.\n\nUID:\n$uid\n\nCreate users/$uid with name and role, then log in again.")
                    return@addOnSuccessListener
                }
                val name = doc.getString("name")?.trim()
                val role = doc.getString("role")?.trim()
                if (name.isNullOrBlank() || role.isNullOrBlank()) {
                    showProfileError("User profile is incomplete.\n\nThe document users/$uid must contain:\nname = your name\nrole = Boss / Team Leader / Technician")
                    return@addOnSuccessListener
                }
                currentName = name
                currentRole = role
                registerDeviceToken(uid)
                requestNotificationPermission()
                startNotificationListener(uid)
                showDashboard()
            }
            .addOnFailureListener {
                showProfileError("Could not read your profile from Firestore.\n\nReason:\n${it.message ?: "Unknown Firestore error"}\n\nCheck internet connection and Firestore rules.")
            }
    }

    private fun showProfileError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Profile / Role Error")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> auth.signOut(); showLogin() }
            .setCancelable(false)
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun registerDeviceToken(uid: String) {
        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                db.collection("deviceTokens").document(uid).set(
                    mapOf(
                        "uid" to uid,
                        "token" to token,
                        "name" to currentName,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
            }
            .addOnFailureListener { toast("Notification registration failed: ${it.message}") }
    }

    private fun startNotificationListener(uid: String) {
        notificationListener?.remove()
        notificationListenerReady = false
        notificationListener = db.collection("notifications")
            .whereEqualTo("userUid", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot == null) return@addSnapshotListener
                if (!notificationListenerReady) {
                    notificationListenerReady = true
                    return@addSnapshotListener
                }
                snapshot.documentChanges
                    .filter { it.type == com.google.firebase.firestore.DocumentChange.Type.ADDED }
                    .forEach { change ->
                        val title = change.document.getString("title") ?: "Workshop Manager"
                        val message = change.document.getString("message") ?: "New notification"
                        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                            showLocalNotification(title, message)
                        }
                    }
            }
    }

    private fun showLocalNotification(title: String, message: String) {
        val channelId = "workshop_notifications"
        val manager = getSystemService(android.app.NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(android.app.NotificationChannel(channelId, "Workshop notifications", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()
        manager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
    }

    private fun showDashboard() {
        val name = currentName ?: return
        val role = currentRole ?: return
        val root = base()
        root.addView(title("Workshop Dashboard"))
        root.addView(TextView(this).apply {
            text = "$name  •  $role"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        })
        val summary = TextView(this).apply {
            text = "Loading work summary..."
            textSize = 16f
            setPadding(0, 10, 0, 20)
        }
        root.addView(summary)
        root.addView(btn("WORK ORDERS") { showOrders() })
        if (role == "Boss") root.addView(btn("NEW WORK REQUEST") { showNewWorkRequest() })
        root.addView(btn("MATERIAL REQUESTS") { showMaterials() })
        root.addView(btn("REPORTS") { showReports() })
        root.addView(btn("NOTIFICATIONS") { showNotifications() })
        root.addView(btn("PROFILE / LOG OUT") { logout() })
        setContentView(scroll(root))

        db.collection("workOrders").get()
            .addOnSuccessListener { snap ->
                val docs = visibleOrders(snap.documents)
                val inProgress = docs.count { it.getString("status") == "In Progress" }
                val waiting = docs.count { it.getString("status") == "Waiting for Material" }
                val done = docs.count { it.getString("status") == "Completed" || it.getString("status") == "Closed" }
                summary.text = "Total: ${docs.size}\nIn progress: $inProgress\nWaiting material: $waiting\nCompleted / closed: $done"
            }
            .addOnFailureListener { summary.text = "Unable to load summary.\n${it.message ?: "Check Firestore rules and internet."}" }
    }

    private fun logout() {
        notificationListener?.remove()
        notificationListener = null
        notificationListenerReady = false
        auth.signOut()
        currentName = null
        currentRole = null
        selectedBefore = null
        selectedAfter = null
        showLogin()
    }

    private fun visibleOrders(docs: List<DocumentSnapshot>): List<DocumentSnapshot> {
        val role = currentRole
        val name = currentName
        if (role == "Boss" || role == "Team Leader") return docs
        return docs.filter { doc ->
            val names = doc.get("assignedNames") as? List<*>
            if (names != null) return@filter names.mapNotNull { it?.toString() }.contains(name)
            val legacy = doc.getString("assignedNames") ?: ""
            legacy.split(",").map { it.trim() }.contains(name)
        }
    }

    private fun assignedNames(doc: DocumentSnapshot): String {
        val list = doc.get("assignedNames") as? List<*>
        if (list != null) return list.mapNotNull { it?.toString() }.joinToString(", ")
        return doc.getString("assignedNames") ?: "Not assigned"
    }

    private fun showOrders() {
        val root = base()
        root.addView(title("Work Orders"))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        if (currentRole == "Boss") root.addView(btn("+ NEW WORK REQUEST") { showNewWorkRequest() })
        root.addView(btn("BACK") { showDashboard() })
        setContentView(scroll(root))

        db.collection("workOrders").orderBy("createdAt", Query.Direction.DESCENDING).get()
            .addOnSuccessListener { snap ->
                list.removeAllViews()
                val docs = visibleOrders(snap.documents)
                if (docs.isEmpty()) {
                    list.addView(TextView(this).apply {
                        text = "No work orders assigned yet."
                        textSize = 18f
                        setPadding(0, 20, 0, 20)
                    })
                    return@addOnSuccessListener
                }
                docs.forEach { doc ->
                    val status = doc.getString("status") ?: "Assigned"
                    val description = doc.getString("description") ?: "No description"
                    val text = "${doc.getString("requestNumber") ?: doc.id}\n$description\nAssigned: ${assignedNames(doc)}\nStatus: $status"
                    list.addView(btn(text) { showOrderDetail(doc.id) })
                }
            }
            .addOnFailureListener {
                list.removeAllViews()
                list.addView(TextView(this).apply { text = "Could not load work orders.\n\n${it.message ?: "Unknown Firestore error"}"; textSize = 16f })
            }
    }

    private fun showNewWorkRequest() {
        if (currentRole != "Boss") {
            toast("Only Boss can create and assign work requests")
            return
        }
        val root = base()
        root.addView(title("New Work Request"))
        val department = input("Requesting department")
        val location = input("Location / house")
        val requester = input("Requester")
        val description = input("Problem / work description")
        root.addView(department); root.addView(location); root.addView(requester); root.addView(description)

        val priority = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Normal", "High", "Urgent"))
        }
        val jobType = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Individual", "Team"))
        }
        root.addView(TextView(this).apply { text = "Priority"; textSize = 16f })
        root.addView(priority)
        root.addView(TextView(this).apply { text = "Job type"; textSize = 16f; setPadding(0, 10, 0, 0) })
        root.addView(jobType)
        root.addView(TextView(this).apply { text = "Assign by employee name (not profession)"; textSize = 17f; setPadding(0, 18, 0, 8) })
        val staffLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(staffLayout)
        val selectedUids = linkedSetOf<String>()
        val selectedNames = linkedSetOf<String>()

        db.collection("users").get()
            .addOnSuccessListener { snap ->
                staffLayout.removeAllViews()
                snap.documents.mapNotNull { d ->
                    val name = d.getString("name")?.trim() ?: return@mapNotNull null
                    if (name == currentName) null else Triple(d.id, name, d.getString("role") ?: "")
                }.sortedBy { it.second.lowercase(Locale.US) }.forEach { item ->
                    staffLayout.addView(CheckBox(this).apply {
                        text = item.second
                        setOnCheckedChangeListener { _, checked ->
                            if (checked) { selectedUids.add(item.first); selectedNames.add(item.second) }
                            else { selectedUids.remove(item.first); selectedNames.remove(item.second) }
                        }
                    })
                }
                if (staffLayout.childCount == 0) staffLayout.addView(TextView(this).apply { text = "No staff profiles found in users collection." })
            }
            .addOnFailureListener { staffLayout.addView(TextView(this).apply { text = "Could not load staff.\n${it.message}" }) }

        root.addView(btn("CREATE WORK ORDER") {
            val desc = description.text.toString().trim()
            if (desc.isEmpty()) { toast("Enter work description"); return@btn }
            if (selectedUids.isEmpty()) { toast("Select at least one employee by name"); return@btn }
            if (jobType.selectedItem.toString() == "Individual" && selectedUids.size != 1) {
                toast("Individual job: select exactly one employee, or choose Team")
                return@btn
            }
            val requestNumber = "WO-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val data = hashMapOf<String, Any>(
                "requestNumber" to requestNumber,
                "requestingDepartment" to department.text.toString().trim(),
                "location" to location.text.toString().trim(),
                "requester" to requester.text.toString().trim(),
                "description" to desc,
                "priority" to priority.selectedItem.toString(),
                "jobType" to jobType.selectedItem.toString(),
                "assignedUids" to selectedUids.toList(),
                "assignedNames" to selectedNames.toList(),
                "assignedByUid" to (auth.currentUser?.uid ?: ""),
                "assignedByName" to (currentName ?: ""),
                "status" to "Assigned",
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("workOrders").add(data)
                .addOnSuccessListener { ref ->
                    selectedUids.forEachIndexed { index, uid ->
                        createNotification(uid, "New work assigned", "${selectedNames.elementAt(index)}: $requestNumber has been assigned to you.", ref.id)
                    }
                    toast("Work order created: $requestNumber")
                    showOrders()
                }
                .addOnFailureListener { toast("Could not create work order: ${it.message ?: "Unknown Firestore error"}") }
        })
        root.addView(btn("BACK") { showDashboard() })
        setContentView(scroll(root))
    }

    private fun showOrderDetail(id: String) {
        db.collection("workOrders").document(id).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { toast("Work order not found"); showOrders(); return@addOnSuccessListener }
                val assigned = assignedNames(doc)
                if (currentRole == "Technician") {
                    val names = doc.get("assignedNames") as? List<*>
                    val allowed = names?.mapNotNull { it?.toString() }?.contains(currentName) == true || assigned.split(",").map { it.trim() }.contains(currentName)
                    if (!allowed) { toast("This work order is not assigned to you"); showOrders(); return@addOnSuccessListener }
                }
                val root = base()
                root.addView(title(doc.getString("requestNumber") ?: id))
                root.addView(TextView(this).apply {
                    text = "Department: ${doc.getString("requestingDepartment") ?: "-"}\nLocation: ${doc.getString("location") ?: "-"}\nRequester: ${doc.getString("requester") ?: "-"}\nPriority: ${doc.getString("priority") ?: "-"}\nJob type: ${doc.getString("jobType") ?: "-"}\nAssigned: $assigned\nStatus: ${doc.getString("status") ?: "Assigned"}\n\n${doc.getString("description") ?: ""}"
                    textSize = 16f
                    setPadding(0, 0, 0, 15)
                })

                val before = decodePhoto(doc.getString("beforePhotoBase64"))
                val after = decodePhoto(doc.getString("afterPhotoBase64"))
                if (before != null) {
                    root.addView(TextView(this).apply { text = "BEFORE PHOTO"; textSize = 18f; setPadding(0, 8, 0, 6) })
                    root.addView(ImageView(this).apply { setImageBitmap(before); adjustViewBounds = true })
                }
                if (after != null) {
                    root.addView(TextView(this).apply { text = "AFTER PHOTO"; textSize = 18f; setPadding(0, 16, 0, 6) })
                    root.addView(ImageView(this).apply { setImageBitmap(after); adjustViewBounds = true })
                }

                val statusSpinner = Spinner(this).apply {
                    adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Assigned", "In Progress", "Waiting for Material", "Completed", "Closed"))
                    val wanted = doc.getString("status") ?: "Assigned"
                    setSelection((adapter as ArrayAdapter<String>).getPosition(wanted).coerceAtLeast(0))
                }
                root.addView(TextView(this).apply { text = "Update status"; textSize = 16f; setPadding(0, 12, 0, 4) })
                root.addView(statusSpinner)
                root.addView(btn("UPDATE STATUS") {
                    val newStatus = statusSpinner.selectedItem.toString()
                    db.collection("workOrders").document(id).update("status", newStatus)
                        .addOnSuccessListener {
                            notifyAssigned(doc, "Work order status changed", "${doc.getString("requestNumber") ?: id}: $newStatus", id)
                            toast("Status updated")
                            showOrderDetail(id)
                        }
                        .addOnFailureListener { toast("Status update failed: ${it.message}") }
                })
                root.addView(btn("REQUEST MATERIAL") { showMaterialForm(id) })
                root.addView(btn("COMPLETION REPORT + BEFORE/AFTER PHOTOS") { showCompletion(id) })
                if (currentRole == "Boss") root.addView(btn("DELETE WORK ORDER") { confirmDelete(id) })
                root.addView(btn("BACK") { showOrders() })
                setContentView(scroll(root))
            }
            .addOnFailureListener { toast("Could not open work order: ${it.message}"); showOrders() }
    }

    private fun confirmDelete(id: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete work order?")
            .setMessage("This will permanently remove the work order and its report.")
            .setPositiveButton("DELETE") { _, _ ->
                db.collection("workOrders").document(id).delete()
                    .addOnSuccessListener { toast("Work order deleted"); showOrders() }
                    .addOnFailureListener { toast("Delete failed: ${it.message}") }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showMaterialForm(orderId: String? = null) {
        val root = base()
        root.addView(title("Material Request"))
        val material = input("Material name")
        val quantity = input("Quantity")
        val reason = input("Reason / why needed")
        val order = input("Work order number (optional)")
        if (orderId != null) { order.setText(orderId); order.isEnabled = false }
        root.addView(material); root.addView(quantity); root.addView(reason); root.addView(order)
        root.addView(btn("SUBMIT MATERIAL REQUEST") {
            val m = material.text.toString().trim()
            val q = quantity.text.toString().trim()
            if (m.isEmpty() || q.isEmpty()) { toast("Enter material and quantity"); return@btn }
            val uid = auth.currentUser?.uid ?: ""
            val data = mapOf(
                "workOrderId" to order.text.toString().trim(),
                "material" to m,
                "quantity" to q,
                "reason" to reason.text.toString().trim(),
                "requestedBy" to (currentName ?: ""),
                "requestedByUid" to uid,
                "status" to "Requested",
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("materialRequests").add(data)
                .addOnSuccessListener {
                    notifyBossAndLeaders("New material request", "$m • $q • Requested by ${currentName ?: "user"}")
                    toast("Material request submitted")
                    showMaterials()
                }
                .addOnFailureListener { toast("Material request failed: ${it.message}") }
        })
        root.addView(btn("BACK") { if (orderId != null) showOrderDetail(orderId) else showDashboard() })
        setContentView(scroll(root))
    }

    private fun showMaterials() {
        val root = base()
        root.addView(title("Material Requests"))
        root.addView(btn("+ NEW MATERIAL REQUEST") { showMaterialForm(null) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(btn("BACK") { showDashboard() })
        setContentView(scroll(root))

        val materialQuery = if (currentRole == "Boss" || currentRole == "Team Leader") {
            db.collection("materialRequests").orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection("materialRequests").whereEqualTo("requestedByUid", auth.currentUser?.uid ?: "")
        }
        materialQuery.get()
            .addOnSuccessListener { snap ->
                list.removeAllViews()
                val docs = if (currentRole == "Boss" || currentRole == "Team Leader") snap.documents else snap.documents.sortedByDescending { it.getLong("createdAt") ?: 0L }
                if (docs.isEmpty()) {
                    list.addView(TextView(this).apply { text = "No material requests yet."; textSize = 18f; setPadding(0, 20, 0, 20) })
                } else docs.forEach { doc ->
                    val text = "${doc.getString("material") ?: "-"} • ${doc.getString("quantity") ?: "-"}\nStatus: ${doc.getString("status") ?: "Requested"}\nRequested by: ${doc.getString("requestedBy") ?: "-"}\nWork order: ${doc.getString("workOrderId")?.ifBlank { "-" } ?: "-"}"
                    if (currentRole == "Boss" || currentRole == "Team Leader") list.addView(btn(text) { updateMaterialStatus(doc.id, doc.getString("status") ?: "Requested", doc) })
                    else list.addView(TextView(this).apply { this.text = text; textSize = 16f; setPadding(0, 14, 0, 14) })
                }
            }
            .addOnFailureListener { list.addView(TextView(this).apply { text = "Could not load material requests.\n\n${it.message}"; textSize = 16f }) }
    }

    private fun updateMaterialStatus(id: String, current: String, doc: DocumentSnapshot) {
        val options = arrayOf("Requested", "Approved", "Purchased", "Rejected")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            setSelection(options.indexOf(current).coerceAtLeast(0))
        }
        AlertDialog.Builder(this)
            .setTitle("Update material status")
            .setView(spinner)
            .setPositiveButton("SAVE") { _, _ ->
                val status = spinner.selectedItem.toString()
                db.collection("materialRequests").document(id).update("status", status)
                    .addOnSuccessListener {
                        val uid = doc.getString("requestedByUid")
                        if (!uid.isNullOrBlank()) createNotification(uid, "Material request updated", "${doc.getString("material") ?: "Material"}: $status", doc.getString("workOrderId"))
                        toast("Material status updated")
                        showMaterials()
                    }
                    .addOnFailureListener { toast("Update failed: ${it.message}") }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showCompletion(id: String) {
        selectedBefore = null
        selectedAfter = null
        val root = base()
        root.addView(title("Completion Report"))
        val problem = input("What was the problem?")
        val work = input("What was done?")
        val used = input("Material used")
        val note = input("Additional problem / note")
        root.addView(problem); root.addView(work); root.addView(used); root.addView(note)

        root.addView(TextView(this).apply { text = "📷 BEFORE PHOTO"; textSize = 18f; setPadding(0, 16, 0, 6) })
        beforeImage = ImageView(this).apply { adjustViewBounds = true; minimumHeight = 150 }
        root.addView(beforeImage)
        root.addView(btn("📷 CAPTURE BEFORE PHOTO") { capture("before") })
        root.addView(btn("🖼 SELECT BEFORE PHOTO") { selectGallery("before") })

        root.addView(TextView(this).apply { text = "📷 AFTER PHOTO"; textSize = 18f; setPadding(0, 16, 0, 6) })
        afterImage = ImageView(this).apply { adjustViewBounds = true; minimumHeight = 150 }
        root.addView(afterImage)
        root.addView(btn("📷 CAPTURE AFTER PHOTO") { capture("after") })
        root.addView(btn("🖼 SELECT AFTER PHOTO") { selectGallery("after") })

        photoStatus = TextView(this).apply { text = "Before: not selected\nAfter: not selected"; textSize = 15f; setPadding(0, 10, 0, 10) }
        root.addView(photoStatus)

        root.addView(btn("SAVE COMPLETION") {
            val done = work.text.toString().trim()
            if (done.isEmpty()) { toast("Enter what was done"); return@btn }
            val data = hashMapOf<String, Any>(
                "completionProblem" to problem.text.toString().trim(),
                "completionWork" to done,
                "materialUsed" to used.text.toString().trim(),
                "additionalNote" to note.text.toString().trim(),
                "completedBy" to (currentName ?: ""),
                "completedByUid" to (auth.currentUser?.uid ?: ""),
                "completedAt" to System.currentTimeMillis(),
                "status" to "Completed"
            )
            saveCompletionWithPhotos(id, data)
        })
        root.addView(btn("BACK") { showOrderDetail(id) })
        setContentView(scroll(root))
    }

    private fun saveCompletionWithPhotos(id: String, data: HashMap<String, Any>) {
        toast("Saving report and photos...")
        executor.execute {
            try {
                selectedBefore?.let { data["beforePhotoBase64"] = encodePhoto(it) }
                selectedAfter?.let { data["afterPhotoBase64"] = encodePhoto(it) }
                runOnUiThread {
                    db.collection("workOrders").document(id).update(data)
                        .addOnSuccessListener {
                            db.collection("workOrders").document(id).get().addOnSuccessListener { doc ->
                                notifyAssigned(doc, "Work completed", "${doc.getString("requestNumber") ?: id} was completed by ${currentName ?: "technician"}.", id)
                            }
                            toast("Completion report saved")
                            showOrderDetail(id)
                        }
                        .addOnFailureListener { toast("Could not save completion: ${it.message}") }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Photo processing failed: ${e.message}") }
            }
        }
    }

    private fun encodePhoto(uri: Uri): String {
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open photo")
        val original = input.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("Cannot decode photo")
        val maxSide = 900
        val scale = minOf(1.0, maxSide.toDouble() / maxOf(original.width, original.height).toDouble())
        val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(original, (original.width * scale).toInt(), (original.height * scale).toInt(), true) else original
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 58, output)
        if (bitmap !== original) bitmap.recycle()
        val bytes = output.toByteArray()
        if (bytes.size > 650_000) throw IllegalStateException("Photo is still too large. Please retake the photo with normal camera quality.")
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun decodePhoto(encoded: String?): Bitmap? {
        if (encoded.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(encoded, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) { null }
    }

    private fun capture(type: String) {
        pendingPhotoType = type
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCamera()
        else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun selectGallery(type: String) {
        pendingPhotoType = type
        galleryLauncher.launch("image/*")
    }

    private fun launchCamera() {
        val directory = File(cacheDir, "images").apply { mkdirs() }
        val file = File(directory, "${pendingPhotoType}_${System.currentTimeMillis()}.jpg")
        cameraUri = FileProvider.getUriForFile(this, "com.workshopmanager.app.fileprovider", file)
        cameraUri?.let { cameraLauncher.launch(it) }
    }

    private fun updatePhotoPreview() {
        beforeImage?.setImageURI(selectedBefore)
        afterImage?.setImageURI(selectedAfter)
        photoStatus?.text = "Before: ${if (selectedBefore != null) "selected" else "not selected"}\nAfter: ${if (selectedAfter != null) "selected" else "not selected"}"
    }

    private fun showReports() {
        val root = base()
        root.addView(title("Reports"))
        val report = TextView(this).apply { text = "Loading reports..."; textSize = 16f }
        root.addView(report)
        root.addView(btn("BACK") { showDashboard() })
        setContentView(scroll(root))
        db.collection("workOrders").get()
            .addOnSuccessListener { snap ->
                val docs = visibleOrders(snap.documents)
                val counts = docs.groupingBy { it.getString("status") ?: "Unknown" }.eachCount()
                report.text = "Total work orders: ${docs.size}\n\n" + if (counts.isEmpty()) "No work orders yet." else counts.entries.sortedBy { it.key }.joinToString("\n") { "${it.key}: ${it.value}" }
            }
            .addOnFailureListener { report.text = "Could not load reports.\n\n${it.message}" }
    }

    private fun showNotifications() {
        val root = base()
        root.addView(title("Notifications"))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(btn("BACK") { showDashboard() })
        setContentView(scroll(root))
        val uid = auth.currentUser?.uid ?: return
        db.collection("notifications").whereEqualTo("userUid", uid).get()
            .addOnSuccessListener { snap ->
                list.removeAllViews()
                val docs = snap.documents.sortedByDescending { it.getLong("createdAt") ?: 0L }
                if (docs.isEmpty()) list.addView(TextView(this).apply { text = "No notifications yet."; textSize = 18f; setPadding(0, 20, 0, 20) })
                docs.forEach { doc ->
                    val title = doc.getString("title") ?: "Workshop Manager"
                    val message = doc.getString("message") ?: ""
                    val read = doc.getBoolean("read") == true
                    list.addView(btn("${if (read) "✓" else "•"} $title\n$message") {
                        db.collection("notifications").document(doc.id).update("read", true)
                    })
                }
            }
            .addOnFailureListener { list.addView(TextView(this).apply { text = "Could not load notifications.\n${it.message}" }) }
    }

    private fun createNotification(userUid: String, title: String, message: String, workOrderId: String?) {
        if (userUid.isBlank()) return
        db.collection("notifications").add(
            mapOf(
                "userUid" to userUid,
                "title" to title,
                "message" to message,
                "workOrderId" to (workOrderId ?: ""),
                "read" to false,
                "createdAt" to System.currentTimeMillis()
            )
        )
    }

    private fun notifyAssigned(doc: DocumentSnapshot, title: String, message: String, workOrderId: String) {
        val uids = doc.get("assignedUids") as? List<*> ?: return
        uids.mapNotNull { it?.toString() }.forEach { createNotification(it, title, message, workOrderId) }
    }

    private fun notifyBossAndLeaders(title: String, message: String) {
        db.collection("users").get().addOnSuccessListener { snap ->
            snap.documents.filter { it.getString("role") == "Boss" || it.getString("role") == "Team Leader" }
                .forEach { createNotification(it.id, title, message, null) }
        }
    }
}
