WORKSHOP MANAGER — CLEAN NEW BUILD 10.0
======================================

Firebase project used:
  project_id = workshope-68a8e
  Android package = com.workshopmanager.app

WHAT THIS NEW BUILD FIXES
-------------------------
1. Exact Firebase role loading from users/{AUTH_UID}.
   - No fallback to Technician.
   - Missing profile gives a clear error with the UID.
2. Boss sees NEW WORK REQUEST.
3. Assignment is by employee NAME, not profession.
4. Individual or Team work order.
5. Work Orders has a real empty state and real Firestore errors.
6. Material Requests works even when there is no work order.
7. Material status: Requested -> Approved -> Purchased -> Rejected.
8. Completion report with BEFORE and AFTER camera/gallery photos.
9. Photos are compressed and stored in Firestore as base64 so this version does not require Firebase Storage.
10. Reports and Notification Center.
11. FCM token registration and Android notification permission.
12. In-app Firestore notifications for assignments, status changes, material requests and completion.
13. FCM receiver is included for server-sent push messages.

STAFF ASSIGNMENT
----------------
Boss: Mr. Luter
Team Leader: Gizachew
Electromechanical: Seyoum
Electrician: Zekarias
Wood & Metal: Wondesson
Painters: Shega, Ebissa, Mengesha A.
Masonry & Construction: Mengesha E.
Daily Labour: Daily Labour

IMPORTANT
---------
Do NOT delete the Firebase project, Authentication users, or Firestore users collection just because old APK files were deleted.
The new app intentionally uses the existing Firebase project and existing user accounts.

FIRESTORE RULES
---------------
Copy firestore.rules into Firebase Console -> Firestore Database -> Rules and publish it.

AUTOMATIC PUSH NOTIFICATIONS
----------------------------
The Android app contains FCM receiving and token registration.
The app also creates notification documents, which are visible in the Notification Center and can trigger a local notification while the app is open.
For true automatic push when the recipient's app is closed, deploy the optional Firebase Cloud Functions backend in the functions/ folder.
Cloud Functions deployment requires the Firebase project to use the Blaze plan.
Do not upgrade billing just to build/test the APK; first test the app and decide whether automatic push is required.

BUILD
-----
The GitHub workflow builds:
  WorkshopManager-New-APK

The extracted APK is normally larger than the compressed GitHub artifact. That is normal.
